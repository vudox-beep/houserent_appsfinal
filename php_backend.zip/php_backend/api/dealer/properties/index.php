<?php
require_once '../../cors.php';
require_once '../../db.php';
require_once '../../auth.php';

$user = authorize(['dealer', 'admin']);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $conn->prepare("
            SELECT p.*, 
                   (SELECT COUNT(*) FROM leads l WHERE l.property_id = p.id) as leads_count
            FROM properties p
            WHERE p.dealer_id = ?
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$user['id']]);
        $properties = $stmt->fetchAll();

        foreach ($properties as &$prop) {
            $imgStmt = $conn->prepare("SELECT image_path FROM property_images WHERE property_id = ?");
            $imgStmt->execute([$prop['id']]);
            $prop['images'] = $imgStmt->fetchAll(PDO::FETCH_COLUMN);
        }

        echo json_encode($properties);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["message" => "Server error fetching dealer properties"]);
    }
} else {
    http_response_code(405);
}
?>