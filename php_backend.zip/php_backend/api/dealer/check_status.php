<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../db.php';
require_once '../../auth.php';

// Handle preflight OPTIONS request for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) $data = $_POST;
if (!$data) $data = $_GET;

$user_id = $data['user_id'] ?? '';

// Fallback to token if user_id is not explicitly provided
if (empty($user_id)) {
    $headers = apache_request_headers();
    if (isset($headers['Authorization'])) {
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        // Add logic to decode token if you use JWT, or query DB for token
        // In our current setup, token is a random string or JWT depending on the actual implementation
        // For now, let's assume user_id is required
    }
}

if (empty($user_id)) {
    echo json_encode(['status' => 'error', 'message' => 'User ID required', 'is_locked' => true]);
    exit;
}

// Check user role and identity verification
$stmtUser = $conn->prepare("SELECT role, identity_verified FROM users WHERE id = ?");
$stmtUser->execute([$user_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['status' => 'error', 'message' => 'User not found', 'is_locked' => true]);
    exit;
}

if ($user['role'] !== 'dealer') {
    echo json_encode(['status' => 'success', 'message' => 'User is not a dealer', 'is_dealer' => false, 'is_locked' => false]);
    exit;
}

$stmt = $conn->prepare("SELECT subscription_status, subscription_expiry FROM dealers WHERE user_id = ?");
$stmt->execute([$user_id]);
$dealerData = $stmt->fetch(PDO::FETCH_ASSOC);

$sub_status = 'inactive';
$expiry = null;

if ($dealerData) {
    $sub_status = $dealerData['subscription_status'];
    $expiry = $dealerData['subscription_expiry'];
    
    // Check if expired
    if ($sub_status === 'active' && strtotime($expiry) < time()) {
        $sub_status = 'expired';
        $upd = $conn->prepare("UPDATE dealers SET subscription_status = 'expired' WHERE user_id = ?");
        $upd->execute([$user_id]);
    }
}

$is_locked = ($sub_status !== 'active');

echo json_encode([
    'status' => 'success',
    'is_dealer' => true,
    'subscription_status' => $sub_status,
    'subscription_expiry' => $expiry,
    'identity_verified' => $user['identity_verified'],
    'is_locked' => $is_locked,
    'lock_message' => $is_locked ? 'Your subscription has expired or is inactive. Please make a payment to continue using the app.' : ''
]);
?>