<?php
require_once '../cors.php';
require_once '../db.php';
require_once '../auth.php';

$user = authorize(['user', 'tenant']);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $conn->prepare("
            SELECT r.*, p.title, p.location, p.price, p.property_type,
                   d.name as landlord_name, d.phone as landlord_phone
            FROM rentals r
            JOIN properties p ON r.property_id = p.id
            JOIN users d ON r.dealer_id = d.id
            WHERE r.tenant_id = ?
            ORDER BY r.created_at DESC
        ");
        $stmt->execute([$user['id']]);
        $rentals = $stmt->fetchAll();

        foreach ($rentals as &$rental) {
            $payStmt = $conn->prepare("
                SELECT * FROM rent_payments 
                WHERE rental_id = ? 
                ORDER BY created_at DESC LIMIT 1
            ");
            $payStmt->execute([$rental['id']]);
            $rental['latest_payment'] = $payStmt->fetch() ?: null;
        }

        echo json_encode($rentals);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["message" => "Server error fetching rentals"]);
    }
} else {
    http_response_code(405);
}
?>