<?php

class SimpleMailer {
    private $fromEmail = "no-reply@houseforrent.site";
    private $fromName = "HouseRent Africa";
    
    // In the future, if you want to use SMTP, you can configure it here 
    // using PHPMailer or a similar library.
    
    public function send($to, $subject, $body) {
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: {$this->fromName} <{$this->fromEmail}>" . "\r\n";
        $headers .= "Reply-To: {$this->fromEmail}" . "\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();

        // Attempt to send the email using PHP's native mail function
        return @mail($to, $subject, $body, $headers);
    }
}
?>